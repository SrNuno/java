package bol8_ej3.clases;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileNameExtensionFilter;

public class EventManage extends JFrame implements ActionListener {
    JButton btnCargar;
    JTextArea textAreaContenido;
    JLabel lblImagen;
    File f, fAuxiliar;

    public EventManage() {
        super("Boletín8_Ejercicio3");
        this.setLayout(new FlowLayout());
        btnCargar = new JButton("Cargar archivos");
        add(btnCargar);
        btnCargar.addActionListener(this);

        lblImagen = new JLabel();
        add(lblImagen);

        textAreaContenido = new JTextArea(20, 30);
        textAreaContenido.setVisible(false);
        add(textAreaContenido);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        int respuesta;
        JFileChooser fc = new JFileChooser();
        FileNameExtensionFilter filtroImagenes = new FileNameExtensionFilter("Imágenes",
                "jpg", "jpeg", "gif", "png");
        FileNameExtensionFilter filtroTexto = new FileNameExtensionFilter("Archivos de texto",
                "txt");

        fc.addChoosableFileFilter(filtroImagenes);
        fc.addChoosableFileFilter(filtroTexto);
        fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        respuesta = fc.showOpenDialog(this);

        String extension = String.valueOf(fc.getSelectedFile());
        String finalExtension = "";
        int punto = extension.lastIndexOf('.');
        if (punto > 0) {
            finalExtension = extension.substring(punto + 1);
        }

        if (respuesta == JFileChooser.APPROVE_OPTION) {
            f = fc.getSelectedFile();
            if (f.isDirectory()) {
                String[] listaElementos = f.list();
                lblImagen.setVisible(false);
                textAreaContenido.setEditable(false);
                for (int i = 0; i < listaElementos.length; i++) {
                    fAuxiliar = new File(fc.getSelectedFile().getPath() + "/" + listaElementos[i]);
                    if (fAuxiliar.isDirectory()) {
                        textAreaContenido.append(String.format("D~%s\n", fAuxiliar.getName()));
                        textAreaContenido.setVisible(true);
                    } else {
                        textAreaContenido.append(String.format("%s\n", listaElementos[i]));
                        textAreaContenido.setVisible(true);
                    }
                }
                System.out.println();

            } else {
                if (finalExtension.equals("txt")) {
                    String contenido = "";
                    try (Scanner sc = new Scanner(f)) {
                        textAreaContenido.setVisible(true);
                        textAreaContenido.setLineWrap(true);
                        textAreaContenido.setText("");
                        while (sc.hasNext()) {
                            contenido = sc.nextLine();
                            textAreaContenido.append(contenido);
                            textAreaContenido.setSize(textAreaContenido.getPreferredSize());
                        }
                        lblImagen.setVisible(false);
                        System.out.println();
                    } catch (IOException ex) {
                        System.err.println("Error de acceso al archivo");
                    }

                } else if (finalExtension.equals("jpg") || finalExtension.equals("jpeg") || finalExtension.equals("gif")
                        || finalExtension.equals("png")) {
                    lblImagen.setIcon(new ImageIcon(fc.getSelectedFile().getPath()));
                    lblImagen.setSize(lblImagen.getPreferredSize());
                    lblImagen.setVisible(true);
                    lblImagen.setText("");
                    this.setSize(lblImagen.getWidth() + 20, lblImagen.getHeight() + 80);

                } else {
                    lblImagen.setVisible(true);
                    textAreaContenido.setVisible(false);
                    lblImagen.setIcon(null);
                    lblImagen.setText(String.format(
                            "<html>Nombre: %s <br> Trayectoria: %s <br> Tamaño: %dKB <br> Permiso de Lectura: %b, permiso de Escritura: %b, permiso de Ejecución: %b",
                            fc.getSelectedFile().getName(), fc.getSelectedFile().getPath(),
                            fc.getSelectedFile().length() / 1024, fc.getSelectedFile().canRead(),
                            fc.getSelectedFile().canWrite(), fc.getSelectedFile().canExecute()));
                }
            }
        }
    }
}
